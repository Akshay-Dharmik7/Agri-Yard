
<html>
    <head>
    <link href=".../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/global.css" rel="stylesheet">
    <link href="../css/main_index.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Do+Hyeon&display=swap" rel="stylesheet">
    <script src="js/jquery-2.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="footer_1 clearfix">
                    <div class="col-sm-3">
                        <div class="footer_1l clearfix">
                            <a class="navbar-brand" href="index.html"><i class="fa fa-leaf"></i> AgriYard</a>
                        </div>
                    </div>


                    <div class="col-sm-9" >
                        <div class="footer_2i clearfix" style="float:right">
                            <h4 class="col mgt" >CONTACT INFO</h4>
                            <ul>
                                <li>+91-2345678910</li>
                                <li>info@agriyard.com</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer_2 clearfix">
                    </div>
                    
                </div>
                <div class="footer_3 text-center clearfix">
                    <p class="mgt col">© 2023 AgriYard. All Rights Reserved | 
                </div>
            </div>
        </div>
    </section>
    </body>
</html>