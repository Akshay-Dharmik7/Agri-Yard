
<html>
    <head>
   
    </head>

    <body>
    <!-- footer -->
    <section id="footer" class="myfooter" style=" background-color: #009a4e;">
        <div class="container">
            <div class="row text-center text-xs-center text-sm-left text-md-left">
                <div class="col aligncenter">
                    <br>
                    <h5 style="color:white">Payment Option</h5>
                    <img src="../Images/Website/paytm1.jpg" alt="paytm">
                    <img src="../Images/Website/cod.jpg" alt="paytm" style="height:37px">
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5" >
                    <ul class="list-unstyled list-inline social text-center" >
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
                        <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
                    </ul>
                </div>
                </hr>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center" style="font-size:20px ">
                    <p style="color:white">AgriYard is a Multitrading Company for farmers and traders</p>
                    <p class="h6" style=" color:white">Copy All right Reversed.</p>
                </div>
                </hr>
            </div>
        </div>
    </section>
    <!-- ./Footer a ,myfooter,aligncenter-->
 
    </body>
</html>